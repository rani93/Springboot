package com.example.CarService;

import org.junit.jupiter.api.Test;


class Demo2ApplicationTest {

    @Test
    void contextLoads() {
    }
}