package com.example.website.service;

public interface MessageService {
	public String createMessage(int userId);
}
