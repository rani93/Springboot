package com.example.website.domain;

public interface UserMessage {
  public void setUserId(int userId);
}
