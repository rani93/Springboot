package com.codingNinjas.carDealership;

public interface Car {
	public String getInfo();
	public void setOwnerName(String name);
	public String getOwnerName();

}
