package com.codingNinjas.carDealership;

public class NormalTyre implements Tyre {

	@Override
	public String getTyreInfo() {
		return " with normal tyres";
	}

}
