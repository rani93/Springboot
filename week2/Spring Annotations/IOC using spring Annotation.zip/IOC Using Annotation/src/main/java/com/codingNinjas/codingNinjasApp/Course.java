package com.codingNinjas.codingNinjasApp;


public interface Course {
	public void setCourseDetails(String courseName);
	public UserList getUserList();
	public Instructor getInstructor();
	public String getCourseName();
}
