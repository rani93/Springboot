package com.example.TuneIn;

public interface User {

    void setUserDetail(String name,Integer age);

    Playlist getPlaylist();
}

