package com.codingNinjas.codingNinjasApp;

public interface Instructor {
	public void setInstructorDetails(String Name,String age);
	public String takeClass();
}
