package com.codingNinjas.codingNinjasApp;

public interface User {
	public String getUserDetails();
	public void setUserDetails(String name, String age, String location, 
			String collegeName);
}
