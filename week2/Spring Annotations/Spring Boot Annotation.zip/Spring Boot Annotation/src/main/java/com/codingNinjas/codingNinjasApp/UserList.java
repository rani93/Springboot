package com.codingNinjas.codingNinjasApp;

import java.util.ArrayList;

public interface UserList {
	public ArrayList<User> getUserList();
	void addUser(User user);
}
