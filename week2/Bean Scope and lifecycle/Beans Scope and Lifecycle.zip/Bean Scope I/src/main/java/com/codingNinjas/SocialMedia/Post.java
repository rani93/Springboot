package com.codingNinjas.SocialMedia;

public interface Post {
	public void setMessage(String message);
	public String getMessage();
}
